jQuery(document).ready(function(){
	jQuery("a[rel^='prettyPhoto']").prettyPhoto({ overlay_gallery: false, social_tools: '', deeplinking: false });
});
