<?php
ini_set('memory_limit','256M');
define ('FILE_CACHE_DIRECTORY', '../cache');
define ('MAX_WIDTH', 2500);
?>