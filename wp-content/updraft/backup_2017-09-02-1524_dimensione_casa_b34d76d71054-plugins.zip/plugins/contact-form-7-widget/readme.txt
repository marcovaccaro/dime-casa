=== Contact Form 7 Widget ===
Contributors: sswells
Donate link: http://blog.strategy11.com/donate/
Tags: widgets, contact, contact form, widget, sidebar
Requires at least: 2.8
Tested up to: 2.8.4
Stable tag: 1.0

Use your Contact Form 7 forms and other shortcodes in your sidebars.

== Description ==
Use any of your Contact Form 7 Forms in your sidebars. You can even style it from the widget options. This will also work with any other shortcodes that only work in posts. Just insert the shortcode (ie [contact-form 1 "Contact form 1"]) in the 'Contact Form 7 tag' text field. Leave styling options blank in order to style from your theme's css.

note: rounded corners do not work in Internet Explorer… Surprise! Get a different browser!
another note: Use 6 digit hex colors for better results 

== Installation ==
1. Install the Contact Form 7 Plugin
2. Upload `contact-form-7-widget.php` to the `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Go to the 'Widgets' menu and drag the 'Contact Form 7' widget to your sidebar and input your options.

== Screenshots ==

1. The widget options
2. The widget in the sidebar
3. The widget with styling options.
note: Rounded corners do not work in Internet Explorer. 
note: Use 6 digit hex colors for better results